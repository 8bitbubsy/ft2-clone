If the program can't start at all, you might need to install
"Microsoft Visual C++ Redistributable for Visual Studio 2015, 2017 and 2019"
which can be found here:
https://support.microsoft.com/en-us/help/2977003/the-latest-supported-visual-c-downloads

Only install one of them. If you have 64-bit Windows, you need x64, if you have 32-bit, you need x86.