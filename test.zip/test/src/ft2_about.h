#pragma once

#include <stdint.h>

void aboutFrame(void);
void seedAboutScreenRandom(uint32_t newseed);
void showAboutScreen(void);
void hideAboutScreen(void);
void exitAboutScreen(void);
