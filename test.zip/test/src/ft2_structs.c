#include "ft2_structs.h"

cpu_t cpu;
editor_t editor;
ui_t ui;
cursor_t cursor;
