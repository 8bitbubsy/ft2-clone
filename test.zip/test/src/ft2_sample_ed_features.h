#pragma once

#include <stdint.h>

void pbSampleResample(void);
void pbSampleEcho(void);
void pbSampleMix(void);
void pbSampleVolume(void);
void handleEchoToolPanic(void);
