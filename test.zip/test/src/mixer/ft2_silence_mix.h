#pragma once

#include <stdint.h>
#include "../ft2_audio.h"

void silenceMixRoutine(voice_t *v, int32_t numSamples);
